﻿namespace Advertisements;

public abstract class InputExсeption
{
    public static int InputExсeptionCatch(int MenuItems) 
    {
        var inputDigit = 0;
        var inputExceptionCatch = true;
        
        while (inputExceptionCatch)
        {
            try
            {
                inputDigit = Convert.ToInt32(Console.ReadLine());
            }
            catch (Exception)
            {
                Console.WriteLine("\nВы ввели не подходящий символ, попробуйте еще раз, пожалуйста.\n");
                continue;
            }
    
            if (inputDigit > 0 && inputDigit < MenuItems + 1)
            {
                inputExceptionCatch = false;
            }
            else
            {
                Console.WriteLine("\nВы ввели не подходящий символ, попробуйте еще раз, пожалуйста.\n");
            }
        }
        
        return inputDigit - 1;
    }
}