﻿namespace Advertisements;

public class LoginAndRegistration
{
    private int _authorizationCount;

    private enum AuthorizationMenu 
    {
         Login,
         Registration,
         ProgramExit
    }
    
    public void ShowAuthorizationMenu(AdvertisementBoard advertisementBoard)
    {
        var isAuthorized = false;
        User activeUser = null;
        
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine("\nНе авторизированные пользователи не могут создавать объявления! Успешная авторизация возможна только, если у вас есть аккаунт или после его регистарции.\n");
        Console.ResetColor();
        
        while(!isAuthorized) 
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("1. Авторизоваться.");
            Console.WriteLine("2. Зарегестрироваться.");
            Console.WriteLine("3. Выйти из программы.");
            Console.ResetColor();
            Console.Write("\nВыберите действие: ");
            
            Console.ForegroundColor = ConsoleColor.Yellow;
            var authorizationMenu = (AuthorizationMenu)InputExсeption.InputExсeptionCatch(3);
            Console.ResetColor();
            
            switch (authorizationMenu) 
            {
                case AuthorizationMenu.Login:
                    if (IsLoginSuccessful(advertisementBoard, ref activeUser)) 
                    {
                        isAuthorized = true;
                    }
                    break;
                
                case AuthorizationMenu.Registration:
                    Register(advertisementBoard); 
                    break;
                
                case AuthorizationMenu.ProgramExit:
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("\nВсего хорошего!");
                    Console.ResetColor();
                    Environment.Exit(0);
                    break;
                
                default:
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine("\nВы выбрали действие, не предусмотренное для начала работы в нашем приложении, попробуйте еще раз, пожалуйста.");
                    Console.ResetColor();
                    break;
            }
        }
        
        advertisementBoard.UserAdvertisementMenu(activeUser);
    }

    private bool IsLoginSuccessful(AdvertisementBoard advertisementBoard, ref User activeUser)
    {
        Console.WriteLine("\nВведите, пожалуйста, ваш логин и пароль для авторизации.\n");
        
        Console.Write("Логин: ");
        Console.ForegroundColor = ConsoleColor.Yellow;
        var login = Console.ReadLine();
        Console.ResetColor();
            
        Console.Write("Пароль: ");
        Console.ForegroundColor = ConsoleColor.Yellow;
        var password = Console.ReadLine();
        Console.ResetColor();
        
        var hasAuthorization = advertisementBoard.HasUser(login, password);
        
        if (hasAuthorization)
        {
            _authorizationCount = 0;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("\nВы успешно авторизировались. Добро пожаловать!\n");
            Console.ResetColor();
            activeUser = advertisementBoard.GetUser(login, password);
        }
        else
        {
            _authorizationCount++;
            
            if (_authorizationCount > 4)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"\nВы попытались авторизоваться {_authorizationCount} раз, следующие 5 минут возможность авторизоваться для вас заблокирована " +
                                  $"в целях безопасности. Попробуйте авторизоваться через 5 минут, пожалуйста.");
                Console.ResetColor();
                Environment.Exit(0);
            }
            else 
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("\nЛогин или пароль введены неверно, либо аккаунт с таким логином не существует. Попробуйте ввести логин и пароль еще раз или зарегестрируйтесь, пожалуйста.\n");
                Console.ResetColor();
            }
        }
        
        return hasAuthorization;
    }

    private void Register(AdvertisementBoard advertisementBoard) 
    {
        Console.WriteLine("\nВведите, пожалуйста, ваш логин и пароль для регистрации.");

        var isLoginAvailable = false; 
                                        
        string login = null;
        
        while (!isLoginAvailable) 
        {
            Console.Write("\nЛогин: ");
            
            Console.ForegroundColor = ConsoleColor.Yellow;
            login = Console.ReadLine();
            Console.ResetColor();

            isLoginAvailable = advertisementBoard.IsLoginFree(login);

            if (isLoginAvailable) continue;
            
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("\nТакой логин уже зарегестрирован, попробуйте другой!");
            Console.ResetColor();
        }
        
        Console.Write("Пароль: ");
        
        Console.ForegroundColor = ConsoleColor.Yellow;
        var password = Console.ReadLine();
        Console.ResetColor();
        
        Console.Write("Имя: ");
        
        Console.ForegroundColor = ConsoleColor.Yellow;
        var userName = Console.ReadLine();
        Console.ResetColor();
        
        advertisementBoard.AddNewUser(login, password, userName);
        
        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine("\nВы успешно зарегестрировались!\n");
        Console.ResetColor();
        
        _authorizationCount = 0;
    }
}