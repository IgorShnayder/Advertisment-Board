﻿namespace Advertisements;

public class AdvertisementBoard 
{
    private List<User> _users;
    
    public AdvertisementBoard() 
    {
        _users = new List<User>();
    }

    private enum AdvertisementMenu
    {
        CreateNewAdvertisement,
        ShowUserAdvertisementsTitle, 
        ShowUserAdvertisementFully, 
        DeleteUserAdvertisement,
        DeleteUserAdvertisements, 
        ShowOtherUsersAdvertisements,
        ReturnToAuthorizationMenu, 
        ProgramExit
    } 
    
    public void UserAdvertisementMenu(User user)
         {
             while(true)
             {
                 Console.ForegroundColor = ConsoleColor.Yellow;
                 Console.WriteLine($"Добро пожаловать, {user.GetUserName()}!\n");
                 Console.ResetColor();
                 Console.ForegroundColor = ConsoleColor.Yellow;
                 Console.WriteLine($"Количество ваших объявлений - {user.UserAdvertisementsQuantity()}.\n");
                 Console.ResetColor();
                 Console.ForegroundColor = ConsoleColor.Green;
                 Console.WriteLine("1. Создать новое объявление.");
                 Console.WriteLine("2. Вывести наименования всех ваших объявлений.");
                 Console.WriteLine("3. Показать ваше объявление полностью.");
                 Console.WriteLine("4. Удалить ваше объявление.");
                 Console.WriteLine("5. Удалить все ваши объявления.");
                 Console.WriteLine("6. Показать объявления других пользователей.");
                 Console.WriteLine("7. Выйти из аккаунта и вернуться в меню авторизации.");
                 Console.WriteLine("8. Выйти из программы.\n");
                 Console.ResetColor();
                 Console.Write("Выберите действие: ");
                
                 Console.ForegroundColor = ConsoleColor.Yellow;
                 var consoleMenuItem = (AdvertisementMenu)InputExсeption.InputExсeptionCatch(8);;
                 Console.ResetColor();
                 
                 switch (consoleMenuItem) 
                 {
                     case AdvertisementMenu.CreateNewAdvertisement:
                         CreateNewAdvertisement(user);
                         break;
                    
                     case AdvertisementMenu.ShowUserAdvertisementsTitle:
                         ShowUserAdvertisementsTitle(user);
                         break;
                    
                     case AdvertisementMenu.ShowUserAdvertisementFully:
                         ShowUserAdvertisementFully(user);
                         break;
                    
                     case AdvertisementMenu.DeleteUserAdvertisement:
                         DeleteUserAdvertisement(user);
                         break;
                    
                     case AdvertisementMenu.DeleteUserAdvertisements:
                         DeleteUserAdvertisements(user);
                         break;
                    
                     case AdvertisementMenu.ShowOtherUsersAdvertisements:
                         PrintAllUsersAdvertisement(user);
                         break;
                   
                     case AdvertisementMenu.ReturnToAuthorizationMenu:
                         new LoginAndRegistration().ShowAuthorizationMenu(this);
                         break;
                   
                     case AdvertisementMenu.ProgramExit:
                         ProgramExit();
                         break;
                    
                     default:
                         Console.ForegroundColor = ConsoleColor.Yellow;
                         Console.WriteLine("\nВы выбрали действие, не предусмотренное для работы в этом разделе, попробуйте еще раз, пожалуйста.");
                         Console.ResetColor();
                         break;
                 }
             }
         }
    
    public bool HasUser(string login, string password)  
    {
        return _users.Any(boardUser => boardUser.GetUserLogin() == login && boardUser.GetUserPassword() == password);
    }
    
    public User GetUser(string login, string password)
    { 
        var authorizedUserIndex = _users.FindIndex(boardUser => boardUser.GetUserLogin() == login && boardUser.GetUserPassword() == password);
        return _users[authorizedUserIndex];
    }

    public bool IsLoginFree(string login)
    {
        return _users.All(user => user.GetUserLogin() != login);
    }

    public void AddNewUser(string login, string password, string name)
    {
        _users.Add(new User(login, password, name));
    }
    
    private void PrintAllUsersAdvertisement(User user)
    {
        var haveAdvertisements = false;
        
        if (_users.Count >= 2)
        {
            foreach (var t in _users.Where(t => t.GetUserLogin() != user.GetUserLogin()))
            {
                if (t.UserAdvertisementsQuantity() > 0)
                {
                    haveAdvertisements = true;
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine($"\nОбъявления пользователя {t.GetUserName()}:\n");
                    Console.ResetColor();
                    t.GetAllAdvertisements();
                    Console.WriteLine();
                }
            }
        }
        
        if (_users.Count < 2 || !haveAdvertisements)
        {
            Console.WriteLine("\nНа доске еще нет объявлений других пользователей.\n");
        }
    }
    
    private static void CreateNewAdvertisement(User user)
    {
        Console.Write("\nВведите, пожалуйста, название вашего объявления: ");
        Console.ForegroundColor = ConsoleColor.Yellow;
        var advertisementTitle = Console.ReadLine();
        Console.ResetColor();
                   
        if (user.IsAdvertisementTitleTaken(advertisementTitle))
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("\nУ вас уже есть объявление с таким заголовком, создайте, " +
                              "пожалуйста, другой заголовок.");
            Console.ResetColor();
            return;
        }
                   
        Console.Write("\nВведите, пожалуйста, текст вашего объявления: ");
        Console.ForegroundColor = ConsoleColor.Yellow;
        var advertisementText = Console.ReadLine();
        Console.ResetColor();
                   
        var advertisement = new Advertisement(advertisementTitle, advertisementText);
        user.AddAdvertisement(advertisement);
        Console.WriteLine();
    }

    private static void ShowUserAdvertisementsTitle(User user)
    {
        Console.WriteLine();
        if (user.UserAdvertisementsQuantity() > 0)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("\nВаши объявления: \n");
            Console.ResetColor();
            user.AllAdvertisementsTitlePrint();
        }
        else
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("У вас нет созданных объявлений.\n");
            Console.ResetColor();
        }
    }

    private static void ShowUserAdvertisementFully(User user)
    {
        if (user.UserAdvertisementsQuantity() > 0)
        {
            Console.Write("\nВведите номер объявления, которое хотите вывести на экран: ");
                       
            var advertisementNumber = InputExсeption.InputExсeptionCatch(user.UserAdvertisementsQuantity());
                       
            if (advertisementNumber >= 0 && advertisementNumber <= user.UserAdvertisementsQuantity())
            {
                user.AdvertisementTitleAndNamePrint(advertisementNumber);
                Console.WriteLine();
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("\nУ вас нет объявления с таким номером.\n");
            }
        }
                   
        else
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("\nУ вас нет созданных объявлений.\n");
            Console.ResetColor();
        }
    }

    private static void DeleteUserAdvertisement(User user)
    {
        if (user.UserAdvertisementsQuantity() > 0)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("\nВведите номер объявления, которое хотите удалить:\n");
            Console.ResetColor();
                   
            Console.ForegroundColor = ConsoleColor.Yellow;
            var numberOfAdvertisement = InputExсeption.InputExсeptionCatch(user.UserAdvertisementsQuantity());
            Console.ResetColor();
                       
            user.DeleteUserAdvertisement(numberOfAdvertisement);
        }
        else
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("\nУ вас нет созданных объявлений.\n");
            Console.ResetColor();
        }
    }

    private static void DeleteUserAdvertisements(User user)
    {
        if (user.UserAdvertisementsQuantity() > 0)
        {
            user.DeleteUserAllAdvertisement();
        }
        else
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("\nУ вас нет созданных объявлений.\n");
            Console.ResetColor();
        }
    }
    
    private static void ProgramExit()
    {
        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine("\nВсего хорошего!");
        Console.ResetColor();
        Environment.Exit(0);
    }
}