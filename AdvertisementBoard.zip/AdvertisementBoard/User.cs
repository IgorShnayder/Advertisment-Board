﻿namespace Advertisements;

public class User
{
    private string _login;
    private string _password;
    private string _userName;
    private List<Advertisement> _advertisements;

    public User(string login, string password, string name)
    {
        _login = login;
        _password = password;
        _userName = name;
        _advertisements = new List<Advertisement>();
    }

    private enum AdvertisementDeleteMenu
    {
        DeleteAdvertisement,
        NotDelete
    }
    
    public string GetUserLogin()
    {
        return _login;
    }

    public string GetUserPassword()
    {
        return _password;
    }

    public string GetUserName()
    {
        return _userName;
    }

    public void AddAdvertisement(Advertisement advertisement)
    {
        _advertisements.Add(advertisement);
    }
    
    public void GetAllAdvertisements()
    {
        foreach (var advertisement in _advertisements)
        {
            Console.Write("Заголовок: ");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"{advertisement.GetAdvertisementTitle()}");
            Console.ResetColor();
            Console.Write("Текст объявления: ");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"{advertisement.GetAdvertisementText()}\n");
            Console.ResetColor();
        }
    }
    
    public void DeleteUserAdvertisement(int index)
    {
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine("\nВаше объявление будет удалено безвозвратно. Вы действительно готовы удалить его?\n");
        Console.ResetColor();
        
        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine("1. Да.");
        Console.WriteLine("2. Нет.");
        Console.ResetColor();
        Console.Write("\nВыберите действие: ");
                       
        Console.ForegroundColor = ConsoleColor.Yellow;
        var consoleMenuItem = (AdvertisementDeleteMenu)InputExсeption.InputExсeptionCatch(2);;
        Console.ResetColor();

        switch (consoleMenuItem)
        {
            case AdvertisementDeleteMenu.DeleteAdvertisement:
                _advertisements.RemoveAt(index);
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("\nВаше объявление удалено.\n");
                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine($"У вас {_advertisements.Count} объявлений.\n");
                Console.ResetColor();
                break;
            
            case AdvertisementDeleteMenu.NotDelete:
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("\nВы можете продолжить работать с вашими объявлениями.");
                Console.ResetColor();
                break;
            
            default:
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("\nВы выбрали действие, не предусмотренное для работы в этом разделе, попробуйте еще раз, пожалуйста.");
                Console.ResetColor();
                break;
        }
    }

    public void DeleteUserAllAdvertisement()
    {
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine("\nВсе ваши объявления будут удалены безвозвратно. Вы действительно готовы удалить их?\n");
        Console.ResetColor();

        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine("1. Да.");
        Console.WriteLine("2. Нет.");
        Console.ResetColor();
        Console.Write("\nВыберите действие: ");

        Console.ForegroundColor = ConsoleColor.Yellow;
        var advertisementDeleteMenu = (AdvertisementDeleteMenu)InputExсeption.InputExсeptionCatch(2);
        Console.ResetColor();

        switch (advertisementDeleteMenu)
        {
            case AdvertisementDeleteMenu.DeleteAdvertisement:
                _advertisements.Clear();
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("\nВсе объявления удалены.\n");
                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine($"У вас {_advertisements.Count} объявлений.\n");
                Console.ResetColor();
                break;

            case AdvertisementDeleteMenu.NotDelete:
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("\nВы можете продолжить работать с вашими объявлениями.");
                Console.ResetColor();
                break;

            default:
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine(
                    "\nВы выбрали действие, не предусмотренное для работы в этом разделе, попробуйте еще раз, пожалуйста.");
                Console.ResetColor();
                break;
        }
    }

    public int UserAdvertisementsQuantity()
    {
        return _advertisements.Count;
    }

    public bool IsAdvertisementTitleTaken(string name)
    {
       return _advertisements.Any(advertisement => advertisement.GetAdvertisementTitle() == name);
    }

    public void AllAdvertisementsTitlePrint()
    {
        for (var i = 0; i < _advertisements.Count; i++)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"{i + 1}. {_advertisements[i].GetAdvertisementTitle()}\n");
            Console.ResetColor();
        }
    }

    public void AdvertisementTitleAndNamePrint(int index)
    {
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine("\nВаше объявление: \n");
        Console.ResetColor();
        Console.Write($"Заголовок объявления: ");
        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine($"{_advertisements[index].GetAdvertisementTitle()}\n");
        Console.ResetColor();
        Console.Write("Текст объявления: ");
        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine($"{_advertisements[index].GetAdvertisementText()}");
        Console.ResetColor();
    }
}